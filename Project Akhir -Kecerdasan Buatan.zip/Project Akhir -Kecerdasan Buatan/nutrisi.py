import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

# Load dataset
data = pd.read_csv("USDA.csv")

# Drop baris yang ada NaN di kolom penting
data = data.dropna(subset=['Calories', 'Protein', 'TotalFat', 'Carbohydrate'])

# Buat label kategori berdasarkan kandungan protein
def protein_category(protein):
    if protein <= 5:
        return 'Low'
    elif protein <= 15:
        return 'Medium'
    else:
        return 'High'

data['Category'] = data['Protein'].apply(protein_category)

# Fitur dan label
X = data[['Calories', 'Protein', 'TotalFat', 'Carbohydrate']]
y = data['Category']

# Preprocessing 
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# Model
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

# Evaluasi
y_pred = knn.predict(X_test)
print(classification_report(y_test, y_pred))
