# Sistem Pakar Sederhana: Rekomendasi Jurusan Kuliah
rules = [
    {"if": ["suka matematika", "nilai fisika tinggi"], "then": "Teknik"},
    {"if": ["nilai biologi tinggi", "suka membantu orang"], "then": "Kedokteran"},
    {"if": ["nilai ekonomi tinggi", "suka bisnis"], "then": "Manajemen"},
    {"if": ["suka menggambar", "nilai seni tinggi"], "then": "Desain"},
    {"if": ["suka coding", "nilai matematika tinggi"], "then": "Ilmu Komputer"},
    {"if": ["suka sosial", "nilai sosiologi tinggi"], "then": "Ilmu Komunikasi"}
]

def forward_chaining(rules, facts):
    hasil = []
    for rule in rules:
        if set(rule["if"]).issubset(facts):
            hasil.append(rule["then"])
    return hasil

print("=== Sistem Rekomendasi Jurusan ===")
print("Ketik 'keluar' untuk menghentikan program.\n")

while True:
    input_fakta = input("Masukkan minat/nilai siswa (pisahkan dengan koma): ").lower()
    
    if input_fakta.strip() in ["keluar", "exit"]:
        print("Terima kasih telah menggunakan sistem rekomendasi.")
        break

    fakta = set(input_fakta.split(", "))
    rekomendasi = forward_chaining(rules, fakta)

    if rekomendasi:
        print("Rekomendasi jurusan kuliah:")
        for jurusan in rekomendasi:
            print("- " + jurusan)
    else:
        print("Belum ada jurusan yang sesuai dengan data yang dimasukkan.")
    
    print("\n")  # Spasi agar input berikutnya lebih rapi
